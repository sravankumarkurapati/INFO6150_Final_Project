// Placeholder for future API integration
export const login = async (email, password) => {
  // return await axios.post('/api/login', { email, password });
  return { token: 'demo-token', role: 'admin' };
};